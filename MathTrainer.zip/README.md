# [Math Trainer]

Math Trainer is a game for developing math skills of child.